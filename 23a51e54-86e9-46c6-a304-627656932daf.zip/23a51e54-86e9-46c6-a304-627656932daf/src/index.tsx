import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './components/App/index';
import './index.scss';
import { Provider } from 'react-redux';
import { store } from './store/store';

const root = document.getElementById('root');

const rootElement = createRoot(root);

rootElement.render(
  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  <Provider store={store}>
    <App />
  </Provider>,
);
