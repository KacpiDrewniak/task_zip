export enum Category {
  All = 'All',
  Frontend = 'Frontend',
  Backend = 'Backend',
  QA = 'QA',
  Fullstack = 'Fullstack',
}

export enum Currency {
  PLN = 'PLN',
  USD = 'USD',
  GBP = 'GBP',
  EUR = 'EUR',
}
