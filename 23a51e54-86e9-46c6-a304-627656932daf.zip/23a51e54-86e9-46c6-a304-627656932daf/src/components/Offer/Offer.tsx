import React, { FC, useEffect, useState } from 'react';
import style from './Offer.scss';
import { useAppDispatch, useAppSelector } from '../../store/store';
import services from '@services/index';
import { Currency } from '@enum';
import { toggleFavourite } from '../../store/slices/favouriteSlice';

interface OfferProps {
  offer: {
    id: string;
    title: string;
    salary: number;
    description: string;
    category: string;
    url: string;
  };
}

export const getOfferColorClassName = (category?: string): string =>
  ({
    Frontend: style.frontendOffer,
    Backend: style.backendOffer,
    QA: style.testingOffer,
    FullStack: style.fullStackOffer,
  }[category]);

export const OfferComponent: FC<OfferProps> = ({ offer }) => {
  const dispatch = useAppDispatch();

  const ids = useAppSelector((state) => state.favourite.ids);

  const isAlreadyFavorite = ids.includes(offer.id);

  const [currencyData, setCurrencyData] = useState<any>();
  useEffect(() => {
    (async () => {
      const currency = await services.getActualCurrency();
      setCurrencyData(currency.data.data);
    })();
  });
  const currency = useAppSelector((state) => state.search.currency);

  return (
    <div className={`${style.offerContainer} ${getOfferColorClassName(offer.category)}`} data-testid="Offer">
      {offer.category}
      <div className={style.offerHeader}>
        <h3>{offer.title}</h3>
        {currencyData ? (
          <span data-testid="salary">
            {/*//@ts-ignore*/}
            {Math.round(offer.salary / currencyData[currency])} {currency}
          </span>
        ) : null}
      </div>
      <div className={style.offerDescription}>{offer.description}</div>
      <div className={style.offerFooter}>
        <a href={offer.url} className={style.offerLink}>
          Go to offer
        </a>
        <div className={style.offerFavorite} data-testid="offerFavorite">
          {isAlreadyFavorite ? (
            <span
              onClick={() => dispatch(toggleFavourite(offer.id))}
              data-testid="removeFavorite"
              className={style.favoriteOffer}
            >
              Remove from favorite
            </span>
          ) : (
            <span onClick={() => dispatch(toggleFavourite(offer.id))} data-testid="addFavorite">
              Add to favorite
            </span>
          )}
        </div>
        <div className={style.offerCategory}>{offer.category}</div>
      </div>
    </div>
  );
};
