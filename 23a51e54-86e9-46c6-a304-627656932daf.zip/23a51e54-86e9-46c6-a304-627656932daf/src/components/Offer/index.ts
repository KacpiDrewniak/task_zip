import { OfferComponent } from './Offer';

export default OfferComponent;
