import { HeaderComponent } from './Header';

export default HeaderComponent;
