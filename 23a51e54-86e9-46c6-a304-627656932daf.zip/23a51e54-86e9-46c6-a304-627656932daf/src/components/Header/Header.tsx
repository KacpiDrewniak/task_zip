import React, { FC } from 'react';
import style from './Header.scss';
import { useAppSelector } from '../../store/store';

interface HeaderProps {
  test?: string;
}

export const HeaderComponent: FC<HeaderProps> = () => {
  const ids = useAppSelector((state) => state.favourite.ids);

  return (
    <div className={style.headerContainer} data-testid="Header">
      <h1>Job Offers</h1>
      <div className={style.favoritesContainer}>
        <span>★</span>
        <span className={style.favoritesNumber} data-testid="favoritesNumber">
          {ids.length}
        </span>
      </div>
    </div>
  );
};
