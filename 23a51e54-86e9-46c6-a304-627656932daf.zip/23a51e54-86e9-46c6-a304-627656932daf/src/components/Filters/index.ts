import { FiltersComponent } from './Filters';

export default FiltersComponent;
