import React, { FC, useEffect } from 'react';
import style from './Filters.scss';
import { useAppDispatch, useAppSelector } from '../../store/store';
import { changeCurrency, changeSearchText } from '../../store/slices/searchSlice';
import services from '@services/index';
import { Currency } from '@enum';

interface FiltersProps {
  test?: string;
}

export const FiltersComponent: FC<FiltersProps> = () => {
  const dispatch = useAppDispatch();
  const { search } = useAppSelector((state) => state.search);

  const clearFilters = () => {
    dispatch(changeSearchText(''));
  };

  return (
    <div data-testid="Filters">
      <div className={style.filtersWrapper}>
        <div className={style.searchInputContainer}>
          <label>Search:</label>
          <input
            onFocus={clearFilters}
            onChange={(event) => dispatch(changeSearchText(event.target.value))}
            value={search}
            placeholder="Search list by titles"
            data-testid="searchInput"
            className={style.offersSearchInput}
          />
        </div>
        <div className={style.selectBoxWrapper}>
          <label>Currency:</label>
          <select
            onChange={(e) => dispatch(changeCurrency(e.target.value as Currency))}
            data-testid="currencySelect"
            className={style.selectInput}
          >
            {Object.values(Currency).map((currency) => (
              <option key={currency} value={currency}>
                {currency}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};
