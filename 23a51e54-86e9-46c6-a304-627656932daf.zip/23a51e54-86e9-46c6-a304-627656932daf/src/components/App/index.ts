import { AppComponent } from './App';

export default AppComponent;
