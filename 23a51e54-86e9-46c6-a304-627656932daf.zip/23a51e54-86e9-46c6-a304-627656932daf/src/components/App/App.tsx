import React, { FC, useEffect, useMemo, useRef, useState } from 'react';
import Header from '@components/Header';
import Filters from '@components/Filters';
import style from './App.scss';
import services, { Offer } from '@services/index';
import OfferComponent from '@components/Offer';
import Spinner from '@components/Spinner';
import { useAppSelector } from '../../store/store';

export const AppComponent: FC = () => {
  const [offers, setOffers] = useState<Offer[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingAO, setIsLoadingAO] = useState(false);
  const { search } = useAppSelector((state) => state.search);

  const loadNewOffers = async () => {
    setIsLoadingAO(true);
    await (async () => {
      try {
        const {
          data: { data },
        } = await services.getOffers();
        setOffers([...offers, ...data]);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoadingAO(false);
      }
    })();
  };

  useEffect(() => {
    (async () => {
      setIsLoading(true);
      await (async () => {
        try {
          const {
            data: { data },
          } = await services.getOffers();
          setOffers([...offers, ...data]);
        } catch (err) {
          console.error(err);
        } finally {
          setIsLoading(false);
        }
      })();
    })();
  }, []);

  const handleScroll = (e: any) => {
    const scrollEnd = e.target.scrollHeight - e.target.scrollTop === e.target.clientHeight;
    if (scrollEnd) {
      loadNewOffers().then();
    }
  };

  const memoizedOffers = useMemo(() => {
    const filterOffers = offers.filter((offer) => offer.title.toUpperCase().includes(search.toUpperCase()));

    return (
      <div onScroll={handleScroll} data-tested="Offers" className={style.offersContainer} data-testid="Offers">
        {filterOffers.length ? (
          filterOffers.map((offer) => <OfferComponent key={offer.id} offer={offer} />)
        ) : (
          <div>No results</div>
        )}
        {isLoadingAO && <Spinner />}
      </div>
    );
  }, [offers, search, isLoadingAO]);

  return (
    <div className={style.appContainer} data-testid="App">
      <Header />
      <Filters />
      {isLoading ? <Spinner /> : memoizedOffers}
    </div>
  );
};
