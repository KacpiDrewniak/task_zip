import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Currency } from '@enum';

export type searchSliceType = {
  search: string;
  currency: Currency;
};

const initialState: searchSliceType = {
  search: '',
  currency: Currency.PLN,
};

const searchSlice = createSlice({
  name: 'search',
  initialState,
  reducers: {
    changeSearchText: (state, action: PayloadAction<string>) => {
      state.search = action.payload;
    },
    changeCurrency: (state, action: PayloadAction<Currency>) => {
      state.currency = action.payload;
    },
  },
});

export const { changeCurrency, changeSearchText } = searchSlice.actions;

export default searchSlice;
