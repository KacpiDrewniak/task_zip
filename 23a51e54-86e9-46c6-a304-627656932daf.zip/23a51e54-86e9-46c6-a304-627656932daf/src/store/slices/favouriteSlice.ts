import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export type favouriteSliceType = {
  ids: string[];
};

const initialState: favouriteSliceType = {
  ids: [],
};

const favouriteSlice = createSlice({
  name: 'search',
  initialState,
  reducers: {
    toggleFavourite: (state, action: PayloadAction<string>) => {
      if (state.ids.some((e) => e === action.payload)) {
        const newIds = state.ids.filter((e) => e !== action.payload);
        state.ids = newIds;
      } else {
        state.ids.push(action.payload);
      }
    },
  },
});

export const { toggleFavourite } = favouriteSlice.actions;

export default favouriteSlice;
